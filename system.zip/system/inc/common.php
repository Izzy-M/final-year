<?php

	/*$db=new SQLite3("inc/database");
	$sq=$db->query("SELECT *FROM `images` WHERE `id`<3");
	while($row=$sq->fetchArray()){
		if($row['id']==1){ $prog=$row['image']; }
		if($row['id']==2){ $close=$row['image']; }
	}
	$db->close();*/
	
	echo "<script src='inc/jq.js'></script><script src='inc/jqui.js'></script> <link rel='stylesheet' href='inc/jq-ui.css'>
	<link rel='stylesheet' href='inc/font/css/font-awesome.min.css'>
	<style>
	*{margin:0px; -webkit-user-select:none;}
	a{text-decoration:none;}
	p,h1,h2,h3,h4,h5,h6,li,td{cursor:default;}
	::selection {background-color:Transparent;}
	textarea,input:selection{background-color:#008fff;}
	input[type=text],[type=number],[type=email],[type=date],[type=time]{
		padding:5px;width:200px;border:1px solid #ccc;color:#191970;outline:none;font-size:16px;box-shadow:inset 0px 0px 3px #dcdcdc;
	}
	select{padding:4px;width:200px;border:1px solid grey;color:#191970;outline:none;font-size:16px;font-family:cambria;box-shadow:inset 0px 0px 3px #dcdcdc;}
	.btn{
		background:linear-gradient(to top,#4682b4,lightblue);border:1px solid #4682b4;padding:6px;min-width:80px;color:#fff;outline:none;cursor:pointer;
		font-weight:bold;border-radius:3px;box-shadow:inset 0px 1px 1px #F5F5F5;text-shadow:0px 1px 1px #2f4f4f;border-top:1px solid #B0C4DE;
	}
	.cbtn{
		background:linear-gradient(to top,#DB7093,#FFC0CB);border:1px solid #DB7093;padding:6px;min-width:80px;color:#fff;outline:none;cursor:pointer;
		font-weight:bold;border-radius:3px;box-shadow:inset 0px 1px 1px #F5F5F5;text-shadow:0px 1px 1px #2f4f4f;border-top:1px solid #FFC0CB;
	}
	.btn:hover{color:#E0FFFF;}
	.cbtn:hover{color:#E0FFFF;}
	.wrap{background:transparent;width:100%;height:100%;position:fixed;top:0;left:0;z-index:999;cursor:progress;display:none;color:#4682b4;}
	.overlay{background:transparent;width:100%;height:100%;position:fixed;top:0;left:0;z-index:98;cursor:wait;display:none;}
	.popup,.popup2,.popup3,.popup4,.popup5,.popup6{border:1px solid #fff;top:55%;margin:0 auto;box-shadow:0px 5px 10px rgba(0,0,0,0.8);min-height:100px;width:900px;position:fixed;z-index:99;
		background:rgba(135,206,235,0.7);left:0;right:0;padding:10px;display:none;padding:4px;border-radius:3px; font-family:cambria;
	}

	.wrapholder{background:rgba(0,0,0,0.5);width:100%;height:100%;position:fixed;top:0;left:0;z-index:8;display:none;}
	.btcl{border:2px solid #fff;background:transparent;width:30px;height:30px;border-radius:50%;color:#fff;font-size:18px;}
	.progress{position:fixed;background:#fff;padding:15px;font-family:cambria;top:25%;left:30px;right:30px;color:#4682b4;z-index:999;display:none;
	font-weight:bold;margin:0 auto;max-width:300px; text-align:center;border:1px solid #dcdcdc;border-radius:5px;box-shadow:inset 0px 0px 3px #dcdcdc; }
	</style>";
	
	echo '<div class="popup"><div style="background:#fff;border:1px solid #000;padding:10px;">
	<h4 style="color:#2f4f4f;font-family:cambria;font-size:18px"><span class="ptitle">Title</span> 
	<img src="data:image/png;base64,'.$close.'" height="25" style="float:right;cursor:pointer" onclick="closepop()" title="Close"></h4><br>
	<div style="background:#fff;min-height:200px;max-height:500px;overflow:auto" class="pcontent"></div>
	</div></div><div class="overlay"></div><div class="wrap"></div> 
	<div class="progress"><p><img src="data:image/gif;base64,'.$prog.'"> Processing...</p></div>
	<audio id="Critical"><source src="inc/Critical.wav"></audio><audio id="foreg"><source src="inc/Foreground.wav"></audio>
	<script>
	function _(el){return document.getElementById(el);}
	
	function popup(div,title){
		$(".ptitle").html(title); $(".pcontent").html("<h4 style=\'line-:100px;text-align:center;color:#4682b4\'>Loading...</h4>");
		$(".overlay").fadeIn(); $(".popup").fadeIn(); $(".pcontent").load("controller.php?"+div);
	}
	function popup2(div,title){
		$(".ptitle").html(title); $(".pcontent").html("<h4 style=\'line-:100px;text-align:center;color:#4682b4\'>Loading...</h4>");
		$(".overlay").fadeIn(); $(".popup").fadeIn(); $(".pcontent").load("controller.php?"+div);
	}
	function popup3(div,title){
		$(".ptitle").html(title); $(".pcontent").html("<h4 style=\'line-:100px;text-align:center;color:#4682b4\'>Loading...</h4>");
		$(".overlay").fadeIn(); $(".popup").fadeIn(); $(".pcontent").load("controller.php?"+div);
	}
	function popup4(div,title){
		$(".ptitle").html(title); $(".pcontent").html("<h4 style=\'line-:100px;text-align:center;color:#4682b4\'>Loading...</h4>");
		$(".overlay").fadeIn(); $(".popup").fadeIn(); $(".pcontent").load("controller.php?"+div);
	}
	function popup5(div,title){
		$(".ptitle").html(title); $(".pcontent").html("<h4 style=\'line-:100px;text-align:center;color:#4682b4\'>Loading...</h4>");
		$(".overlay").fadeIn(); $(".popup").fadeIn(); $(".pcontent").load("controller.php?"+div);
	}
	function popup6(div,title){
		$(".ptitle").html(title); $(".pcontent").html("<h4 style=\'line-:100px;text-align:center;color:#4682b4\'>Loading...</h4>");
		$(".overlay").fadeIn(); $(".popup").fadeIn(); $(".pcontent").load("controller.php?"+div);
	}
	function popup7(div,title){
		$(".ptitle").html(title); $(".pcontent").html("<h4 style=\'line-:100px;text-align:center;color:#4682b4\'>Loading...</h4>");
		$(".overlay").fadeIn(); $(".popup").fadeIn(); $(".pcontent").load("controller.php?"+div);
	}
	
	function closepop(){
		$(".overlay").fadeOut(); $(".popup").fadeOut(); $(".pcontent").html(""); 
	}
	
	function showerror(er){
		_("Critical").currentTime=0; _("Critical").play(); alert(er);
	}
	
	function progress(txt){
		if(txt==null){ $(".wrap").fadeOut(); $(".progress").hide(); }
		else{$(".wrap").fadeIn(); $(".progress").show(); }
	}
	
	function valid(id,v){
		var exp=/^[0-9-]+$/;
		if(!v.match(exp)){ _(id).value=v.slice(0,-1); return false;}
		else{ return true; }
	}

	</script>';
	
?>