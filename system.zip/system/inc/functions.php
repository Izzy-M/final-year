<?php
	// ini_set('error_log', 'errors.log');
	function con(){ 
		global $PDO; $PDO = new PDO("sqlite:inc/database","",""); $PDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_WARNING); 
	}
	
	con();
	$sid=file_get_contents("inc/session.dll"); 
	
	$sql=$PDO->query("SELECT *FROM `images`");
	foreach($sql->fetchAll() as $row){
		$images[$row['id']]=$row['image'];
	}
	
	function clean($data){
		return htmlentities(htmlentities(addslashes(trim($data))),ENT_QUOTES); 
	}
	
	function prepare($data){
		return html_entity_decode(html_entity_decode(stripslashes(stripslashes($data))));
	}
	
	function getfiles($folder){
		$items="";
		if($handle=opendir($folder)){
			while(false !==($file=readdir($handle))){
				if(($file !=".") and ($file !="..")){
					$items.="$file,";
				}
			}
			closedir($handle);
			return rtrim($items,",");
		}
	}
	
	function delfiles($dir){
		if(is_dir($dir)){
			$files=array_diff(scandir($dir),array(".",".."));
			foreach($files as $file){
				(is_dir("$dir/$file")) ? delfiles("$dir/$file"):unlink("$dir/$file");
			}
			return rmdir($dir);
		}
	}
	
	function error($text){
		return "<div style='padding:10px;color:#FF6347;background:#FFF0F5;text-align:center;border:1px solid pink;margin:0 auto;max-wdth:500px'>$text</div>";
	}
	
	function prenum($id){
		if(strlen($id)==1){$res="00$id";}elseif(strlen($id)==2){$res="0$id";}else{$res=$id;} return $res;
	}
	
	function fnum($v){
		$d=@explode(".",$v); $adn=@$d[1];
		if($adn==null){return strrev(rtrim(chunk_split(strrev($v),3,","),","));}
		else{return strrev(rtrim(chunk_split(strrev($d[0]),3,","),",")).".$adn";}
	}
	
	function isJson($str){
		$str=(is_array($str)) ? json_encode($str,true):$str; json_decode($str);
		return (is_numeric($str)) ? 0:(json_last_error()==JSON_ERROR_NONE);
	}
	
	function checkcon(){
		$con=@fsockopen("www.mabnets.com",80);
		if($con){
			$iscon=true; fclose($con);
		}
		else{ $iscon=false; }
		return $iscon;
	}
		
	function request($url,$data){
		$str=http_build_query($data);
		$ch=curl_init();
		curl_setopt($ch,CURLOPT_URL,$url);
		curl_setopt($ch,CURLOPT_POST,1);
		curl_setopt($ch,CURLOPT_POSTFIELDS,$str);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,false);
		$result=curl_exec($ch);
		$err=curl_errno($ch); curl_close($ch);
		return ($err!=0) ? $err:$result;
	}
	
?>