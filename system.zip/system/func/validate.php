<?php
global $PDO;
$PDO= new PDO("sqlite:common/db","","");
$PDO->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_WARNING);
echo "OK"

?>