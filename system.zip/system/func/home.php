
<head>
  <script src="common/jq.js"></script><script src="common/jqui.js"></script>
<link rel="stylesheet" href="../common/font/css/font-awesome.css" type="text/css">
<link rel="stylesheet" href="..common/jqui.css" type="text/css">
    <style>
    ::selection{background-color: transparent;}
    .body{height:100%;width:100%;background-color: #f0f0f0;}
    .head{height:10%;width:94%;background-color: cyan;padding-left: 80px;margin-top: -5px;}
    .sidenav{height:91%;width:15%;background-color: darkgray;color:#fff;text-shadow:;font-size:20;
    font-family: Rockwell;margin-top:-25px;}
    .section{height:91%;width:85%;background-color:#e6e6fa;margin-top:-25px;}
   .sidenav ol li{list-style: none;padding:10px;position: relative; cursor:pointer;}
   .log{height:50px;width:50px;float:right; }
   .tim{float:right;}
   .holder{height:20px;width:20px;float:right;display: block;}
   .holder1{height:20px;width:20px;float:right;display: none;}
</style>
</head>
<body>
    <div class="body">
    <div class="head">
    <div class="tim"><?php echo date('M d, h:i a');?></div><div class="log"><i class="fa fa-power-off"></i>LogOut</div>
    
   <div style="float:left;margin-left:50px;padding-top:20px;cursor:pointer"> Desert</div>
<div style="float:left;margin-left:50px;padding-top:20px;cursor:pointer">Wine</div>
<div style="float:left;margin-left:50px;padding-top:20px;cursor:pointer">Softdrinks</div>
   <div style="float:left;margin-left:50px;padding-top:20px;cursor:pointer"> Snacks</div>
    <div style="float:left;margin-left:50px;padding-top:20px;cursor:pointer">Dinner</div>
    <div style="float:left;margin-left:50px;padding-top:20px;cursor:pointer">Lunch</div>

    

    </div>
    <aside>
    <div class="sidenav">
        <h4 >QUICK ACCESS</h4>
        <div class="holder" id="cr"><i class="fa fa-caret-left fa-2x"onclick="sidenav('r')" title="Restore"></i></div>
        <div class="holder" id="cl"><i class="fa fa-caret-right fa-2x" onclick="sidenav('c')"title="Colapse"></i></div>
        <ol>
        <li><i class="fa fa-home"></i> Home</li>
        <li><i class="fa fa-database"></i>  Sales</li>
       <li><i class="fa fa-database"></i>  Stock</li>
       <li><i class="fa fa-clipboard"></i>  Reports</li>
       <li><i class="fa fa-fax"></i>  Daily Sales</li>
       <li><i class="fa fa-shopping-cart"></i>  Orders</li>
       <li><i class="fa fa-shopping-basket"></i> Suppliers</li>
    
        </ol>

    </div>
    </aside>
    <div class="section"></div>
</body>

<script>
    function sidenav(k){
        if(k=="c"){
            $(".holder").show();$("#cl").hide();$("#cr").css("display","none");
        }
        else{
            $("#cl").show();$("#cr").hide();
        }

    }
</script>